def send_server(self):
    print("send reached")
    no_client = True
    while 1:
        if len(client_Peer.peers) != 0:
            try:
                val = self.gui.input_text[-1]
                self.gui.input_text.pop()
                if val == '':
                    break
            except:
                val = ''
            file_info = ''
            if val != '' and val != 'Enter file;Back':
                val = val.split(';')

                if val[0] == "Enter file":
                    file_path = val[1]  # G:\file1\file 2\file 3\file 4\xtx.txt
                    try:
                        with open(file_path, 'rb') as file:
                            file_info = file.read(10000).decode('utf-8')  # Read up to 10000 bytes and decode
                    except:
                        self.gui.error_popup = True
                        print("path doesnt exist")
                        val = ''
                        break
                    chunks = chunk_splitter().split_data(file_info, len(client_Peer.peers))
                    for c in chunks:
                        print("chunk", c)
                    if not self.does_file_exist_in_db(os.path.basename(val[1])):
                        sent_to = sent_file(os.path.basename(val[1]), file_path)
                        tmp_count = 1
                        for i in client_Peer.peers:
                            send_val = val[0] + ';' + val[1] + ';' + str(
                                tmp_count) + ';' + chunks.pop(0)
                            i.send_q.put(send_val)  # Enter file;{file path};{the number of this chunk};{the information of the chunk}
                            sent_to.sent_to.append(str(i.ip))  # remember who we sent to
                            tmp_count = tmp_count + 1
                        self.record_sent_peers(sent_to)
                    else:
                        self.gui.error_popup = True
                        print("file already entered")

                elif val[0] == "Request file":
                    file_name = os.path.basename(val[1])  # xtx.txt
                    print(f"in req file {file_name}")
                    if not self.does_file_exist_in_db(file_name):
                        self.gui.error_popup = True
                        print("path doesnt exist")
                        break
                    send_val = val[0] + ';' + file_name  # Request file;"name"
                    for i in client_Peer.peers:
                        i.send_q.put(send_val)
                try:
                    print(f"sent value is {send_val}")
                except UnboundLocalError:
                    pass  # there is no value yet
        elif no_client:
            print("no client connected")  # add ui
            no_client = False
