import os
import random
from common import *


class file_manager:
    def __init__(self):  # tml will have file "users" and file "code"
        self.root_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        self.i = int(0)

    def generate_file_name(self):
        """Generate a random string of letters and digits."""
        self.i = self.i + 1
        return ''.join([str(self.i)] + ['.'] + random.choices(inconspicuous_file_names))

    def generate_random_path(self):
        """Generate a random path within the existing directory structure."""
        current_dir = os.path.join(self.root_dir, "Users")  # Start from the Users directory

        # Descend into subdirectories randomly
        for _ in range(random.randint(1, 5)):
            sub_dirs = [d for d in os.listdir(current_dir) if os.path.isdir(os.path.join(current_dir, d))]
            if not sub_dirs:
                break  # If no subdirectories found, break the loop
            current_dir = os.path.join(current_dir, random.choice(sub_dirs))
        return rf"{current_dir}\{self.generate_file_name()}"
