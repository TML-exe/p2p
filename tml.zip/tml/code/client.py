import socket
from threading import Thread
from common import *  # Assuming common contains shared variables like Globals, recv_q, etc.
import time
from encryption import secure_socket  # Importing the SecureSocket class from the encryption module
import find_ip

class Client(Thread):
    def __init__(self):
        Thread.__init__(self)
        self.peers = []  # List to store multiple peer connections
        print("client start")

    def connect_to_server(self):
        while True:
            ip_scan = find_ip.IP_scanner()
            self.server_ip_list = ip_scan.scan_all_ips()
            print(len(self.server_ip_list))
            for ip in self.server_ip_list:
                try:
                    my_socket = socket.socket()  # Create a new socket for each connection
                    my_socket.connect((ip, Globals.port))
                    peer = client_Peer(ip, my_socket)  # Pass the socket to the peer
                    self.peers.append(peer)
                    client_Peer.add_peers(peer)
                    recv_q.put(f"found server at {ip}")
                    print("338723", f"client connect to server at {ip}")
                except Exception as e:
                    print(f"couldn't connect to ip {ip}")
                    pass
            if len(self.server_ip_list) == 0:
                pass
            time.sleep(20)

    def client_send(self, peer):
        while True:
            if not peer.send_q.empty():
                msg = peer.send_q.get()
                encrypted_msg = self.encryption.encrypt(msg)  # Encrypt the message
                peer.my_socket.send(encrypted_msg.encode('utf-8'))
            time.sleep(0.02)

    def handle_peer(self, peer):
        secure_s = secure_socket()
        while True:
            try:
                data = peer.my_socket.recv(1024)
                decrypted_data = secure_s.decrypt(data.decode('utf-8'))  # Decrypt received data
                recv_q.put(decrypted_data)
            except OSError:
                pass  # no client connected

    def run(self):
        thread_conn = Thread(target=self.connect_to_server, args=())
        thread_conn.start()

        while True:
            for peer in self.peers:
                thread_send = Thread(target=self.client_send, args=(peer,))
                thread_send.start()
                thread_handle = Thread(target=self.handle_peer, args=(peer,))
                thread_handle.start()
            time.sleep(1)


if __name__ == "__main__":
    print("usage: python main.py")

