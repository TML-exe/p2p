import os
import sqlite3

import server
from client import Client
from time import sleep
from threading import Thread
from common import *
import gui as ui
from dev_txt import chunk_splitter
from recreate_file import file_assembler


class main_thread(Thread):
    def __init__(self):
        Thread.__init__(self)
        print("mainThread start")
        self.more_than_2 = True

    def run(self):
        while True:  # handles answer
            if not recv_q.empty():
                msg = recv_q.get()
                print(msg + " is message")
                parts = msg.split(';')
                if parts[0] == "found server":
                    a = Client()  # create another client
                    a.start()
                elif parts[0] == "Request file response":  # Request file;file name;num;data
                    if parts[1] == "File not found":
                        print("peers didn't find file")
                        break
                    original_path = self.get_original_path(parts[1])
                    file_path = original_path if original_path else fr'{os.path.dirname(os.path.dirname(os.path.abspath(__file__)))}\output_combined.txt'
                    total_chunks = self.count_peer(parts[1])
                    print(str(total_chunks) + " is total num of chunks")
                    data_write = ";".join([parts[2], parts[3]])
                    with open(file_path, 'a') as f_out:
                        with open(file_path, 'r') as file:
                            data_read = file.read()
                        if data_read == '':
                            f_out.write(data_write)
                            print("File is empty")
                        else:
                            f_out.write(';' + data_write)
                    with open(file_path, 'r') as file:
                        data_read = file.read()
                    numbers = []
                    print(f"{data_read} is the data read")
                    data_list = data_read.split(';')
                    print(str(data_list) + " is data list")
                    for i in range(len(data_list)):
                        if i % 2 == 0:
                            print(str(data_list[i]) + " is appended into nums")
                            numbers.append(data_list[i])
                    print(str(numbers) + " is num list")
                    print(str(self.is_seq(numbers)) + " that nums are seq")
                    if self.is_seq(numbers):
                        if len(numbers) == total_chunks:
                            info = self.rearrange_text(data_read)
                            print(info + " is info being printed")
                            with open(file_path, 'w') as file:
                                file.write('')
                            with open(file_path, 'a') as file:
                                file.write(info)
                            # Delete file entry from the database after successful reconstruction
                            self.delete_file_entry(parts[1])

                elif parts[0] == "Enter file":
                    if parts[1] == "File already entered":
                        print("file by the same name already entered, try again.")
                        break
                    try:
                        print(f"{parts[1]}")
                        os.remove(parts[1])
                        print(f"File {os.path.basename(parts[1])} has been deleted successfully.")
                    except OSError as e:
                        print(f"Error deleting the file: {e}")
                else:
                    print("3331 from server ", msg)
            sleep(0.02)  # sleep 20 ms - let the cpu breath

    def is_seq(self, digits):
        if not digits:
            return False

        digits_set = set(digits)
        n = len(digits)

        for i in range(1, n + 1):
            if str(i) not in digits_set:
                return False

        return True

    def rearrange_text(self, jumbled_text):
        # Split the jumbled text into segments
        segments = jumbled_text.split(';')

        # Initialize a dictionary to store segments based on their order
        ordered_segments = {}

        # Iterate over the segments and store them in the dictionary based on their order
        for i in range(0, len(segments), 2):
            order = int(segments[i])
            segment = segments[i + 1]
            ordered_segments[order] = segment

        # Reconstruct the text based on the ordered segments
        ordered_text = ''.join([ordered_segments[i] for i in range(1, len(ordered_segments) + 1)])

        return ordered_text

    def count_peer(self, file_name):  # peers will be peer;peer;peer;peer
        db_file = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'sent_peers.db')
        conn = sqlite3.connect(db_file)
        cursor = conn.cursor()
        cursor.execute("CREATE TABLE IF NOT EXISTS SentPeers (File TEXT, Peer TEXT, OriginalPath TEXT)")

        cursor.execute("SELECT Peer FROM SentPeers WHERE File=?", (file_name,))
        result = cursor.fetchall()  # Fetch all rows

        peers = str([row[0] for row in result]).split(';')  # Extract peer information from the result

        conn.commit()
        conn.close()

        return len(peers)

    def get_original_path(self, file_name):
        db_file = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'sent_peers.db')
        conn = sqlite3.connect(db_file)
        cursor = conn.cursor()

        cursor.execute("SELECT OriginalPath FROM SentPeers WHERE File=?", (file_name,))
        result = cursor.fetchone()  # Fetch one row

        conn.close()

        if result:
            return result[0]
        else:
            return None

    def delete_file_entry(self, file_name):
        db_file = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'sent_peers.db')
        conn = sqlite3.connect(db_file)
        cursor = conn.cursor()
        cursor.execute("DELETE FROM SentPeers WHERE File=?", (file_name,))
        conn.commit()
        conn.close()


class run:
    def __init__(self):
        self.gui = ui.Main_menu()
        self.server = server.server()
        self.client = Client()

    def get_self_entry_data(self, file_name):
        db_file = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'sent_peers.db')
        conn = sqlite3.connect(db_file)
        cursor = conn.cursor()
        file_name = r':self:' + file_name

        cursor.execute("SELECT Peer FROM SentPeers WHERE File=?", (file_name,))
        path_list = cursor.fetchone()  # Fetch one row

        cursor.execute("SELECT OriginalPath FROM SentPeers WHERE File=?", (file_name,))
        og_path = cursor.fetchone()  # Fetch one row
        conn.close()

        if path_list and og_path:
            return path_list, og_path
        else:
            return None

    def record_sent_peers(self, sent_file):  # peers will be peer;peer;peer;peer
        db_file = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'sent_peers.db')
        conn = sqlite3.connect(db_file)
        cursor = conn.cursor()
        cursor.execute("CREATE TABLE IF NOT EXISTS SentPeers (File TEXT, Peer TEXT, OriginalPath TEXT)")

        # Record each peer that has been sent parts of the file
        cursor.execute("INSERT INTO SentPeers (File, Peer, OriginalPath) VALUES (?, ?, ?)",
                       (sent_file.file_name, ';'.join(sent_file.sent_to), sent_file.original_path))

        conn.commit()
        conn.close()

    def record_sent_to_self(self, file_name, path_list,
                            original_path):  # saved value will be File-:self:hi.txt, Peer-path;path;path..., OriginalPath-path
        db_file = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'sent_peers.db')
        conn = sqlite3.connect(db_file)
        cursor = conn.cursor()
        file_name = r":self:" + file_name  # : is an illegal character when naming a file, no risk of accidental flagging
        cursor.execute("CREATE TABLE IF NOT EXISTS SentPeers (File TEXT, Peer TEXT, OriginalPath TEXT)")

        # Record each peer that has been sent parts of the file
        cursor.execute("INSERT INTO SentPeers (File, Peer, OriginalPath) VALUES (?, ?, ?)",
                       (file_name, ';'.join(path_list), original_path))

        conn.commit()
        conn.close()

    def does_file_exist_in_db(self, file_name):
        # Query the database to check if the file exists
        db_file = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'sent_peers.db')
        conn = sqlite3.connect(db_file)
        cursor = conn.cursor()
        cursor.execute("CREATE TABLE IF NOT EXISTS SentPeers (File TEXT, Peer TEXT, OriginalPath TEXT)")

        cursor.execute("SELECT * FROM SentPeers WHERE File=?", (file_name,))
        result = cursor.fetchone()  # Fetch one row

        conn.close()

        print(f"result from sent_peers db is {result}")
        return result is not None

    def main(self):
        server_thread = self.server
        a = main_thread()
        a.start()

        a = Thread(target=server_thread.main_server, args=())
        a.start()

        sleep(3)
        a = self.client
        a.start()

        sleep(3)
        b = Thread(target=self.send_server, args=())
        b.start()

        self.gui.main_loop()

    def send_server(self):
        print("send reached")
        no_client = True
        while 1:
            if len(client_Peer.peers) != 0:
                try:
                    val = self.gui.input_text[-1]
                    self.gui.input_text.pop()
                    if val == '' or val == None:
                        break
                except:
                    val = ''
                if val != None and val != '':
                    print(f"OG main - Val is {val}")
                file_info = ''
                if val != '' and val != 'Enter file;Back' and val != "Request file;Back" and val != 'Self entry;Back':
                    val = val.split(';')

                    if val[0] == "Self entry":
                        if not self.does_file_exist_in_db(os.path.basename(val[1])):
                            self_comp_paths_list = chunk_splitter().split_into_chunks_file(val[1])
                            self.record_sent_to_self(os.path.basename(val[1]), self_comp_paths_list, val[1])
                            print("self entry recorded")
                            try:
                                os.remove(val[1])
                                print("self entry deleted successfully")
                            except OSError:
                                print("couldn't delete self entry")

                        else:
                            self.gui.error_popup = True
                            print("file already entered")


                    elif val[0] == "Enter file":
                        file_path = val[1]  # G:\file1\file 2\file 3\file 4\xtx.txt
                        try:
                            with open(file_path, 'rb') as file:
                                while True:
                                    file_info_chunk = file.read(4096).decode('utf-8')  # Read up to 4K from the file
                                    if not file_info_chunk:
                                        break  # no more info to read
                                    file_info += file_info_chunk
                        except:
                            self.gui.error_popup = True
                            print("path doesnt exist")
                            val = ''
                            break
                        chunks = chunk_splitter().split_data(file_info, len(client_Peer.peers))
                        for c in chunks:
                            print("chunk", c)
                        if not self.does_file_exist_in_db(os.path.basename(val[1])):
                            sent_to = sent_file(os.path.basename(val[1]), file_path)
                            tmp_count = 1
                            for i in client_Peer.peers:
                                send_val = val[0] + ';' + val[1] + ';' + str(
                                    tmp_count) + ';' + chunks.pop(0)
                                i.send_q.put(
                                    send_val)  # Enter file;{file path};{the number of this chunk};{the information of the chunk}
                                sent_to.sent_to.append(str(i.ip))  # remember who we sent to
                                tmp_count = tmp_count + 1
                            self.record_sent_peers(sent_to)
                        else:
                            self.gui.error_popup = True
                            print("file already entered")

                    elif val[0] == "Request file":
                        file_name = os.path.basename(val[1])  # xtx.txt
                        print(f"in req file {file_name}")
                        if not self.does_file_exist_in_db(file_name):
                            if self.does_file_exist_in_db(r':self:' + file_name):
                                print("OG MAIN - in request loop, found self entry!!")
                                result_ret = self.get_self_entry_data(file_name)
                                if result_ret:
                                    path_list, og_path = result_ret
                                    file_assembler(str(path_list).split(";")).assemble_files_into_memory(str(og_path))
                                    break
                            else:
                                self.gui.error_popup = True
                                print("path doesnt exist")
                                break
                        send_val = val[0] + ';' + file_name  # Request file;"name"
                        for i in client_Peer.peers:
                            i.send_q.put(send_val)
                    try:
                        print(f"sent value is {send_val}")
                    except UnboundLocalError:
                        pass  # there is no value yet
            elif no_client:
                print("no client connected")  # add ui
                no_client = False


if __name__ == "__main__":
    r = run()
    r.main()
