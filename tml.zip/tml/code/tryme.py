def clean_path(path):
    """
    Clean up and remove excessive backslashes from a path string.

    Args:
    path (str): The path string to be cleaned.

    Returns:
    str: The cleaned path string.
    """
    # Remove extra characters like parentheses and commas
    path = path.strip("(),'")

    # Replace quadruple backslashes with double backslashes
    cleaned_path = path.replace('\\\\\\\\', '\\\\')

    # Replace double backslashes with a single backslash
    cleaned_path = cleaned_path.replace('\\\\', '\\')

    return cleaned_path

# Example usage
example_path = r"('C:\\\\Users\\\\landi\\\\OneDrive\\\\שולחן העבודה\\\\carrossel\\\\i present at dawn\\\\tml\\\\Users\\\\file1\\\\file 2\\\\file 3\\\\file 4\\\\bbb.txt',)"
cleaned_path = clean_path(example_path)
print(cleaned_path)
