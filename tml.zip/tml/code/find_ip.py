import threading
import socket
import re
from common import Globals

class IP_scanner:
    def __init__(self):
        self.port = Globals.port
        self.IP_list = []
        self.my_IP = self.get_ip_address()
        self.ip_range = self.IP_range_getter()

    def IP_range_getter(self):
        match = re.match(r"(\d+\.\d+\.\d+\.)", self.my_IP)
        return match.group(1) if match else None

    def get_ip_address(self):
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
                s.connect(("8.8.8.8", 80))
                return s.getsockname()[0]
        except Exception as e:
            print(f"Error: {e}")
            return "Unable to get IP address"

    def scan_port(self, ip):
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as client_socket:
                client_socket.settimeout(1)
                client_socket.connect((ip, self.port))
                print(f"Port {self.port} is open on {ip}")
                self.IP_list.append(ip)
        except socket.error:
            pass

    def scan_all_ips(self):
        threads = []
        for i in range(1, 255):
            ip = f"{self.ip_range}{i}"
            if ip != self.my_IP:
                t = threading.Thread(target=self.scan_port, args=(ip,))
                threads.append(t)
                t.start()
        print("no ip address open on Global port")
        for t in threads:
            t.join()

        return self.IP_list
