from queue import Queue
from typing import List

inconspicuous_file_names = [
    "config",
    "cache",
    "log",
    "log",
    "index",
    "record",
    "audit",
    "inventory",
    "manifest",
    "template",
    "configuration_template",
    "log_template",
    "index_template",
    "record_template",
    "audit_template",
    "inventory_template",
    "manifest_template",
    "configuration_backup",
    "log_backup",
    "index_backup",
    "record_backup",
    "audit_backup",
    "inventory_backup",
    "manifest_backup",
    "settings.cfg",
    "temp.dat",
    "prefs.ini",
    "cache.data",
    "errors.log",
    "debug.log",
    "temp_data.tmp",
    "system_config.sys",
    "network_info",
    "resource_usage",
    "diagnostic_report",
    "protocol_data",
    "security_audit",
    "hardware_inventory",
    "configuration_data",
    "system_logs",
    "performance_metrics",
    "system_errors.log",
    "data_dump.dat",
    "operational_report",
    "incident_report",
    "data_sheet",
    "testing_results",
    "protocol_summary",
    "system_status",
    "resource_summary",
    "diagnostic_summary",
    "equipment_inventory",
]

# send_q = Queue()
recv_q = Queue()


class client_Peer:
    peers: List['client_Peer'] = []  # Specify the type as List['client_Peer']

    def __init__(self, ip):
        self.ip = ip
        self.send_q = Queue()
        self.send_q.empty()

    @classmethod
    def add_peers(cls, peer):
        client_Peer.peers.append(peer)


class sent_file:
    def __init__(self, file_name, original_path):
        self.file_name = file_name  # str
        self.original_path = original_path  # str
        self.sent_to: List[client_Peer] = []  # list


class file_paths_list:
    def __init__(self, name, list):
        self.name = name
        self.list = list


class Globals:
    # srcName=""
    # dstName=""
    port = 1000
    sent_file_list: List[sent_file] = []
    dir = 'g:'
