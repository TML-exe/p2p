import sqlite3


class User_Database:
    def __init__(self, conn_inherit):
        self.db_name = "users.db"
        self.conn = conn_inherit
        print(f"print {self.db_name}")

    def create_users_table(self):
        if self.conn is not None:
            try:
                self.conn.execute('''CREATE TABLE IF NOT EXISTS USERS
                 (
                 username       TEXT PRIMARY KEY   NOT NULL,
                 password      TEXT               NOT NULL,
                 firstName      TEXT               NOT NULL,
                 lastName       TEXT               NOT NULL,
                 gender         TEXT               NOT NULL,
                 bornDate       INT                NOT NULL,
                 email      TEXT               NOT NULL
                 );''')
                self.conn.commit()  # like save?
                print("Table 'USERS' created successfully.")
            except sqlite3.Error as e:
                print(f"Error creating table: {e}")
        else:
            print("Database connection is not established.")

    def close_connection(self):
        if self.conn is not None:
            self.conn.close()
            print(f"Closed the connection to the {self.db_name} database.")
        else:
            print("No active connection to close.")

    def insert_to_table(self, Username, Password, FirstName, LastName, Gender, BornDate, Email):
        self.conn.execute("INSERT INTO USERS (username, password, firstName, lastName, gender, bornDate, email) \
            VALUES (?, ?, ?, ?, ?, ?, ?)", (Username, Password, FirstName, LastName, Gender, BornDate, Email))
        self.conn.commit()

    def user_exists(self, username, password):
        cursor = self.conn.cursor()
        try:
            cursor.execute("SELECT COUNT(*) FROM USERS WHERE username=?", (username,))
            result = cursor.fetchone()
            user_bool = result[0] > 0
        except sqlite3.Error as e:
            print(f"Error checking username existence: {e}")
            return False
        try:
            cursor.execute("SELECT COUNT(*) FROM USERS WHERE password=?", (password,))
            result = cursor.fetchone()
            password_bool = result[0] > 0
        except sqlite3.Error as e:
            print(f"Error checking password existence: {e}")
            return False
        if password_bool and user_bool:
            return True
        else:
            return False
