import pygame
import sys
import os
import pyperclip
import re
import time
from threading import Thread
from common import client_Peer

# Initialize Pygame
pygame.init()

# Screen dimensions
screen_width = 500
screen_height = 500

# Colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
GREEN = (43, 72, 113)
DARK_GREEN = (255, 57, 2)
LIGHT_GREEN = (255, 128, 7)
ORANGE = (255, 30, 0)
DARK_ORANGE = (82, 146, 255)
DARKER_ORANGE = (2, 48, 89)
BACKGROUND_COLOR = '#DCDDD8'

# Fonts
gui_font = pygame.font.Font(None, 30)
emoji_font = pygame.font.Font('C:\\WINDOWS\\FONTS\\SEGUIEMJ.TTF', 30)
error_font = pygame.font.Font('C:\\WINDOWS\\FONTS\\SEGUIEMJ.TTF', 15)


class Button:
    def __init__(self, text, width, height, pos, elevation, font):
        # Core attributes
        self.pressed = False
        self.elevation = elevation
        self.dynamic_elevation = elevation
        self.original_y_pos = pos[1]

        # Top rectangle
        self.top_rect = pygame.Rect(pos, (width, height))
        self.top_color = LIGHT_GREEN
        self.save_top = self.top_color

        # Bottom rectangle
        self.bottom_rect = pygame.Rect(pos, (width, height))
        self.bottom_color = DARK_GREEN

        # event color
        self.eve_color = DARK_ORANGE

        # Text
        self.text_surf = font.render(text, True, WHITE)
        self.text_rect = self.text_surf.get_rect(center=self.top_rect.center)

    def draw(self, screen):
        # Elevation logic
        self.top_rect.y = self.original_y_pos - self.dynamic_elevation
        self.text_rect.center = self.top_rect.center

        self.bottom_rect.midtop = self.top_rect.midtop
        self.bottom_rect.height = self.top_rect.height + self.dynamic_elevation

        pygame.draw.rect(screen, self.bottom_color, self.bottom_rect, border_radius=12)
        pygame.draw.rect(screen, self.top_color, self.top_rect, border_radius=12)
        screen.blit(self.text_surf, self.text_rect)
        return self.check_click()

    def check_click(self):
        mouse_pos = pygame.mouse.get_pos()
        if self.top_rect.collidepoint(mouse_pos):
            self.top_color = self.eve_color
            if pygame.mouse.get_pressed()[0]:
                self.dynamic_elevation = 0
                self.pressed = True
            else:
                self.dynamic_elevation = self.elevation
                if self.pressed:
                    self.pressed = False
                    return True
        else:
            self.dynamic_elevation = self.elevation
            self.top_color = self.save_top
        return False


class InputSendPage:
    def __init__(self, screen, background_image):
        self.screen = screen
        self.background_image = background_image
        pygame.display.set_caption('Input Send')
        self.clock = pygame.time.Clock()
        self.gui_font = gui_font
        self.error_font = error_font
        self.emoji_font = emoji_font
        self.back_button = Button('Back', 200, 40, (150, 400), 5, self.gui_font)
        self.input_rect = pygame.Rect(100, 200, 300, 40)
        self.send_button = Button('✈️', 40, 40, (self.input_rect.right + 10, 200), 5, self.emoji_font)
        self.input_text = ''
        self.error_popup = False

    def main_loop(self):
        while True:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                elif event.type == pygame.MOUSEBUTTONDOWN:
                    if self.back_button.top_rect.collidepoint(event.pos):
                        pygame.display.set_caption('Menu')
                        return 'Back'
                    elif self.send_button.top_rect.collidepoint(event.pos):
                        if os.path.exists(self.input_text):
                            input_text = self.input_text
                            print(f"input txt from ui send is {input_text}")
                            return input_text
                        else:
                            self.error_popup = True
                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_RETURN:
                        self.input_text = ''
                    elif event.key == pygame.K_BACKSPACE:
                        self.input_text = self.input_text[:-1]
                    elif event.key == pygame.K_v and pygame.key.get_mods() & pygame.KMOD_CTRL:
                        self.input_text += pyperclip.paste()
                    else:
                        self.input_text += event.unicode

            self.screen.blit(self.background_image, (0, 0))
            self.back_button.draw(self.screen)
            self.send_button.draw(self.screen)
            pygame.draw.rect(self.screen, WHITE, self.input_rect, border_radius=12)
            input_surface = self.gui_font.render(self.input_text, True, BLACK)
            self.screen.blit(input_surface, (self.input_rect.x + 10, self.input_rect.y + 10))
            label_surface = self.gui_font.render("Enter file path", True, BLACK)
            self.screen.blit(label_surface, (self.input_rect.x, self.input_rect.y - 40))

            if self.error_popup:
                error_surface = self.error_font.render("Error: Invalid file path", True, (255, 0, 0))
                error_rect = error_surface.get_rect(center=(175, 260))
                self.screen.blit(error_surface, error_rect)

            pygame.display.update()
            self.clock.tick(60)


class InputRequestPage:
    def __init__(self, screen, background_image):
        self.screen = screen
        self.background_image = background_image
        pygame.display.set_caption('Input Request')
        self.clock = pygame.time.Clock()
        self.gui_font = gui_font
        self.error_font = error_font
        self.emoji_font = emoji_font
        self.back_button = Button('Back', 200, 40, (150, 400), 5, self.gui_font)
        self.input_rect = pygame.Rect(100, 200, 300, 40)
        self.send_button = Button('✈️', 40, 40, (self.input_rect.right + 10, 200), 5, self.emoji_font)
        self.input_text = ''
        self.error_popup = False

    def main_loop(self):
        while True:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                elif event.type == pygame.MOUSEBUTTONDOWN:
                    if self.back_button.top_rect.collidepoint(event.pos):
                        pygame.display.set_caption('Menu')
                        return 'Back'
                    elif self.send_button.top_rect.collidepoint(event.pos):
                        pattern = r'\.[a-zA-Z0-9]+$'
                        match = re.search(pattern, self.input_text.lower())
                        if not match:
                            self.error_popup = True
                        else:
                            self.error_popup = False
                            return self.input_text
                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_RETURN:
                        self.input_text = ''
                    elif event.key == pygame.K_BACKSPACE:
                        self.input_text = self.input_text[:-1]
                    elif event.key == pygame.K_v and pygame.key.get_mods() & pygame.KMOD_CTRL:
                        self.input_text += pyperclip.paste()
                    else:
                        self.input_text += event.unicode

            self.screen.blit(self.background_image, (0, 0))
            self.back_button.draw(self.screen)
            self.send_button.draw(self.screen)
            pygame.draw.rect(self.screen, WHITE, self.input_rect, border_radius=12)
            input_surface = self.gui_font.render(self.input_text, True, BLACK)
            self.screen.blit(input_surface, (self.input_rect.x + 10, self.input_rect.y + 10))
            label_surface = self.gui_font.render("Enter input", True, BLACK)
            self.screen.blit(label_surface, (self.input_rect.x, self.input_rect.y - 40))

            if self.error_popup:
                error_surface = self.error_font.render("Error: Add file type.", True, (255, 0, 0))
                error_rect = error_surface.get_rect(center=(190, 260))
                self.screen.blit(error_surface, error_rect)

            pygame.display.update()
            self.clock.tick(60)


class SelfEntryPage:
    def __init__(self, screen, background_image):
        self.screen = screen
        self.background_image = background_image
        pygame.display.set_caption('Self Entry')
        self.clock = pygame.time.Clock()
        self.gui_font = gui_font
        self.error_font = error_font
        self.emoji_font = emoji_font
        self.back_button = Button('Back', 200, 40, (150, 400), 5, self.gui_font)
        self.input_rect = pygame.Rect(100, 200, 300, 40)
        self.send_button = Button('✈️', 40, 40, (self.input_rect.right + 10, 200), 5, self.emoji_font)
        self.input_text = ''
        self.error_popup = False

    def main_loop(self):
        while True:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                elif event.type == pygame.MOUSEBUTTONDOWN:
                    if self.back_button.top_rect.collidepoint(event.pos):
                        pygame.display.set_caption('Menu')
                        return 'Back'
                    elif self.send_button.top_rect.collidepoint(event.pos):
                        if os.path.exists(self.input_text):
                            input_text = self.input_text
                            print(f"self entry input txt is {input_text}")
                            return input_text
                        else:
                            self.error_popup = True
                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_RETURN:
                        self.input_text = ''
                    elif event.key == pygame.K_BACKSPACE:
                        self.input_text = self.input_text[:-1]
                    elif event.key == pygame.K_v and pygame.key.get_mods() & pygame.KMOD_CTRL:
                        self.input_text += pyperclip.paste()
                    else:
                        self.input_text += event.unicode

            self.screen.blit(self.background_image, (0, 0))
            self.back_button.draw(self.screen)
            self.send_button.draw(self.screen)
            pygame.draw.rect(self.screen, WHITE, self.input_rect, border_radius=12)
            input_surface = self.gui_font.render(self.input_text, True, BLACK)
            self.screen.blit(input_surface, (self.input_rect.x + 10, self.input_rect.y + 10))
            label_surface = self.gui_font.render("Enter file path", True, BLACK)
            self.screen.blit(label_surface, (self.input_rect.x, self.input_rect.y - 40))

            if self.error_popup:
                error_surface = self.error_font.render("Error: Invalid file path", True, (255, 0, 0))
                error_rect = error_surface.get_rect(center=(175, 260))
                self.screen.blit(error_surface, error_rect)

            pygame.display.update()
            self.clock.tick(60)


class Main_menu:
    def __init__(self):
        pygame.init()
        self.screen = pygame.display.set_mode((screen_width, screen_height))
        self.main_background_image = pygame.image.load('main_background.png').convert()
        self.main_background_image = pygame.transform.scale(self.main_background_image, (screen_width, screen_height))
        self.send_req_background_image = pygame.image.load('send_req_background.png').convert()
        self.send_req_background_image = pygame.transform.scale(self.send_req_background_image, (screen_width, screen_height))
        self.illus_background_image = pygame.image.load('illus_background.png').convert()
        self.illus_background_image = pygame.transform.scale(self.illus_background_image, (screen_width, screen_height))
        pygame.display.set_caption('Menu')
        self.clock = pygame.time.Clock()
        self.gui_font = gui_font
        self.error_font = error_font
        self.emoji_font = emoji_font
        self.send_button = Button('Send File', 200, 40, (150, 150), 5, self.gui_font)
        self.req_button = Button('Request File', 200, 40, (150, 250), 5, self.gui_font)
        self.self_entry_button = Button('Self Entry', 200, 40, (150, 350), 5, self.gui_font)
        self.how_it_works_button = Button('❓', 40, 40, (450, 10), 5, self.emoji_font)
        self.error_button = Button('Error: system error. file cant be read.', 300, 40, (100, 200), 5, self.error_font)
        self.error_button.top_color = DARK_ORANGE
        self.input_text = []
        self.error_popup = False
        self.peer_count = 0

    def update_peer_count(self):
        while True:
            self.peer_count = len(client_Peer.peers)
            time.sleep(1)  # Update every second

    def main_loop(self):
        Thread(target=self.update_peer_count, daemon=True).start()  # Run the peer count update in a separate thread
        while True:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                elif event.type == pygame.MOUSEBUTTONDOWN:
                    if self.send_button.top_rect.collidepoint(event.pos):
                        input_send_page = InputSendPage(self.screen, self.send_req_background_image)
                        self.input_text.append(f"Enter file;{input_send_page.main_loop()}")
                    elif self.req_button.top_rect.collidepoint(event.pos):
                        input_request_page = InputRequestPage(self.screen, self.send_req_background_image)
                        self.input_text.append(f"Request file;{input_request_page.main_loop()}")
                    elif self.self_entry_button.top_rect.collidepoint(event.pos):
                        self_entry_page = SelfEntryPage(self.screen, self.send_req_background_image)
                        self.input_text.append(f"Self entry;{self_entry_page.main_loop()}")
                    elif self.how_it_works_button.top_rect.collidepoint(event.pos):
                        visualization_page = VisualizationPage(self.screen, self.illus_background_image)
                        visualization_page.main_loop()
                    elif self.error_popup and self.error_button.top_rect.collidepoint(event.pos):
                        self.error_popup = False
            self.screen.blit(self.main_background_image, (0, 0))
            if self.error_popup:
                self.error_button.draw(self.screen)
            else:
                self.send_button.draw(self.screen)
                self.req_button.draw(self.screen)
                self.self_entry_button.draw(self.screen)
                self.how_it_works_button.draw(self.screen)

            # Draw peer count
            peer_count_surface = self.gui_font.render(f"{self.peer_count} Peers connected", True, DARKER_ORANGE)
            self.screen.blit(peer_count_surface, (10, 10))

            pygame.display.update()
            self.clock.tick(60)


class VisualizationPage:
    def __init__(self, screen, background_image):
        self.screen = screen
        self.background_image = background_image
        self.clock = pygame.time.Clock()
        self.gui_font = pygame.font.Font(None, 20)
        self.back_button = Button('Back', 100, 40, (50, 450), 5, self.gui_font)
        self.file_transfer_button = Button('File Transfer Visualization', 250, 40, (200, 450), 5, self.gui_font)

    def draw_text(self, text, color, x, y):
        text_surface = self.gui_font.render(text, True, color)
        self.screen.blit(text_surface, (x, y))

    def main_loop(self):
        current_screen = 'main_visualization'

        while True:
            if current_screen == 'main_visualization':
                back_clicked, file_transfer_clicked = self.main_visualization()
                if file_transfer_clicked:
                    current_screen = 'file_transfer_visualization'
                if back_clicked:
                    return  # Return to main menu
            elif current_screen == 'file_transfer_visualization':
                if self.file_transfer_visualization():
                    current_screen = 'main_visualization'

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()

            pygame.display.flip()

    def main_visualization(self):
        self.screen.blit(self.background_image, (0, 0))
        self.draw_text("P2P File Sharing System", BLACK, 20, 20)
        self.draw_text("1. Secure Login", DARKER_ORANGE, 20, 60)
        self.draw_text("2. Split Files into Chunks", DARKER_ORANGE, 20, 100)
        self.draw_text("3. Distribute Chunks to Peers", DARKER_ORANGE, 20, 140)
        self.draw_text("4. Secure Communication", DARKER_ORANGE, 20, 180)
        self.draw_text("5. Reassemble Files on Request", DARKER_ORANGE, 20, 220)

        # Draw nodes and connections
        pygame.draw.circle(self.screen, GREEN, (250, 100), 20)  # User
        pygame.draw.circle(self.screen, DARK_GREEN, (100, 300), 20)  # Peer
        pygame.draw.circle(self.screen, DARK_GREEN, (400, 300), 20)  # Peer
        pygame.draw.circle(self.screen, DARK_GREEN, (250, 400), 20)  # Peer

        pygame.draw.line(self.screen, BLACK, (250, 100), (100, 300), 2)
        pygame.draw.line(self.screen, BLACK, (250, 100), (400, 300), 2)
        pygame.draw.line(self.screen, BLACK, (250, 100), (250, 400), 2)
        pygame.draw.line(self.screen, BLACK, (100, 300), (400, 300), 2)
        pygame.draw.line(self.screen, BLACK, (100, 300), (250, 400), 2)
        pygame.draw.line(self.screen, BLACK, (400, 300), (250, 400), 2)

        self.draw_text("User", WHITE, 235, 90)
        self.draw_text("Peer", WHITE, 85, 290)
        self.draw_text("Peer", WHITE, 385, 290)
        self.draw_text("Peer", WHITE, 235, 390)

        back_clicked = self.back_button.draw(self.screen)
        file_transfer_clicked = self.file_transfer_button.draw(self.screen)

        return back_clicked, file_transfer_clicked

    def file_transfer_visualization(self):
        self.screen.blit(self.background_image, (0, 0))
        self.draw_text("File Transfer Visualization", BLACK, 20, 20)
        self.draw_text("Chunks: Pieces of the file", DARKER_ORANGE, 20, 80)

        # Draw nodes and file transfer
        pygame.draw.circle(self.screen, GREEN, (250, 100), 20)  # User
        pygame.draw.circle(self.screen, DARK_GREEN, (100, 300), 20)  # Peer
        pygame.draw.circle(self.screen, DARK_GREEN, (400, 300), 20)  # Peer
        pygame.draw.circle(self.screen, DARK_GREEN, (250, 400), 20)  # Peer

        pygame.draw.line(self.screen, BLACK, (250, 100), (100, 300), 2)
        pygame.draw.line(self.screen, BLACK, (250, 100), (400, 300), 2)
        pygame.draw.line(self.screen, BLACK, (250, 100), (250, 400), 2)
        pygame.draw.line(self.screen, BLACK, (100, 300), (400, 300), 2)
        pygame.draw.line(self.screen, BLACK, (100, 300), (250, 400), 2)
        pygame.draw.line(self.screen, BLACK, (400, 300), (250, 400), 2)

        # Illustrate file splitting and transfer
        pygame.draw.line(self.screen, (156, 6, 6), (250, 100), (175, 200), 2)
        pygame.draw.line(self.screen, (156, 6, 6), (175, 200), (100, 300), 2)
        pygame.draw.line(self.screen, (156, 6, 6), (250, 100), (325, 200), 2)
        pygame.draw.line(self.screen, (156, 6, 6), (325, 200), (400, 300), 2)
        pygame.draw.line(self.screen, (156, 6, 6), (250, 100), (250, 250), 2)
        pygame.draw.line(self.screen, (156, 6, 6), (250, 250), (250, 400), 2)

        self.draw_text("User", WHITE, 235, 90)
        self.draw_text("Peer", WHITE, 85, 290)
        self.draw_text("Peer", WHITE, 385, 290)
        self.draw_text("Peer", WHITE, 235, 390)
        self.draw_text("Chunk 1", ORANGE, 160, 190)
        self.draw_text("Chunk 2", ORANGE, 335, 190)
        self.draw_text("Chunk 3", ORANGE, 235, 240)

        back_clicked = self.back_button.draw(self.screen)

        return back_clicked


if __name__ == "__main__":
    main_menu = Main_menu()
    main_menu.main_loop()
