import os

class file_assembler:
    def __init__(self, file_paths):
        self.root_dir = r'D:\tml'
        self.file_paths = file_paths  # list

    def clean_path(self, path):
        """
        Clean up and remove excessive backslashes from a path string.

        Args:
        path (str): The path string to be cleaned.

        Returns:
        str: The cleaned path string.
        """
        # Remove extra characters like parentheses and commas
        path = path.strip("(),'")

        # Replace quadruple backslashes with double backslashes
        cleaned_path = path.replace('\\\\\\\\', '\\\\')

        # Replace double backslashes with a single backslash
        cleaned_path = cleaned_path.replace('\\\\', '\\')

        return cleaned_path

    def sort_files(self, files):
        """Sort the file list based on the numerical prefix."""
        for file in files:
            print(file)
        return sorted(files, key=lambda x: int(os.path.basename(x).split('.')[0]))

    def assemble_files_into_memory(self, new_path): #used in self entry
        """Assemble the data chunks into the output file."""
        # Sort the file list based on the numerical prefix
        sorted_files = self.sort_files(self.file_paths)
        new_path = self.clean_path(new_path)

        # Open the output file for writing
        if os.path.exists(new_path):
            new_path = fr'{os.path.dirname(os.path.dirname(os.path.abspath(__file__)))}\output_combined.txt'
            try:
                open(new_path, 'w').close()
            except OSError:
                "out_combined exists. data is being added."
        else:
            open(new_path, 'w').close()
        with open(new_path, 'w') as f_out:
            # Iterate over the sorted files and append their contents to the output file
            for file_path in sorted_files:
                file_path = self.clean_path(str(file_path))
                print(f"OG RECREATE : file_path is {file_path}")
                with open(file_path, 'r') as f_in:
                    f_out.write(f_in.read())

    def assemble_files_txt(self):
        """Assemble the data chunks into the output file."""
        txt = ''
        # Sort the file list based on the numerical prefix
        sorted_files = self.sort_files(self.file_paths)

        # Open the output file for writing

        # Iterate over the sorted files and append their contents to the output file
        for file_name in sorted_files:
            file_path = os.path.join(self.root_dir, file_name)
            with open(file_path, 'r') as f_in:
                for line in f_in:
                    txt += line  # Concatenate the entire line, including the prefix
        return txt
