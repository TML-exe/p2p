import os
import random
import random_path


class chunk_splitter:
    def __init__(self):
        self.path = random_path.file_manager()
        self.chunk_count = 3

    def split_into_chunks_file(self, input_file):
        # read input
        with open(input_file, 'r') as f:
            text = f.read()

        # guess chunk size
        total_length = len(text)
        avg_chunk_size = total_length // self.chunk_count

        # split into chunks
        chunks = []
        start = 0
        for i in range(self.chunk_count - 1):
            chunk_size = random.randint(avg_chunk_size - avg_chunk_size // 2, avg_chunk_size + avg_chunk_size // 2)
            chunks.append(text[start:start + chunk_size])
            start += chunk_size

        # last chunk
        chunks.append(text[start:])
        paths_list = []
        # write to files
        for i, chunk in enumerate(chunks):
            new_path = f"{self.path.generate_random_path()}.txt"
            with open(os.path.join(new_path), 'w') as f:
                f.write(chunk)
            print(f"new path save is : {new_path}")
            paths_list.append(new_path)

        return paths_list

    def split_into_chunks(self, text):
        self.chunk_count = random.randint(1, len(text)-1) # length of total text must be over 1
        self.chunk_count = 3
        path_list = []
        # guess chunk size
        total_length = len(text)
        avg_chunk_size = total_length // self.chunk_count

        # split into chunks
        chunks = []
        start = 0
        for i in range(self.chunk_count - 1):
            chunk_size = random.randint(avg_chunk_size - avg_chunk_size // 2, avg_chunk_size + avg_chunk_size // 2)
            chunks.append(text[start:start + chunk_size])
            start += chunk_size

        # last chunk
        chunks.append(text[start:])

        # write to files
        for i, chunk in enumerate(chunks):
            new_path = f"{self.path.generate_random_path()}.txt"
            path_list.append(new_path)
            with open(os.path.join(new_path), 'w') as f:
                f.write(chunk)

        return path_list

    def split_data(self, txt, chunk_count):

        path_list = []
        # guess chunk size
        if chunk_count == 1:
            return [txt]
        total_length = len(txt)
        avg_chunk_size = total_length // chunk_count

        # split into chunks
        chunks = []
        start = 0
        for i in range(chunk_count - 1):
            chunk_size = random.randint(avg_chunk_size - avg_chunk_size // 2, avg_chunk_size + avg_chunk_size // 2)
            chunks.append(txt[start:start + chunk_size])
            start += chunk_size

        # last chunk
        chunks.append(txt[start:])
        return chunks

