import pygame
import sys

# Initialize Pygame
pygame.init()

# Screen dimensions
WIDTH, HEIGHT = 800, 600

# Colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
GREEN = (0, 255, 0)

# Screen setup
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption('Soccer Game')

# Player settings
player_width, player_height = 50, 50
player1 = pygame.Rect(100, HEIGHT//2 - player_height//2, player_width, player_height)
player2 = pygame.Rect(WIDTH - 100 - player_width, HEIGHT//2 - player_height//2, player_width, player_height)

# Ball settings
ball_size = 30
ball = pygame.Rect(WIDTH//2 - ball_size//2, HEIGHT//2 - ball_size//2, ball_size, ball_size)
ball_speed = [3, 3]

# Movement speed
speed = 5

# Main game loop
clock = pygame.time.Clock()
while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()

    # Key presses
    keys = pygame.key.get_pressed()
    if keys[pygame.K_w] and player1.top > 0:
        player1.y -= speed
    if keys[pygame.K_s] and player1.bottom < HEIGHT:
        player1.y += speed
    if keys[pygame.K_a] and player1.left > 0:
        player1.x -= speed
    if keys[pygame.K_d] and player1.right < WIDTH:
        player1.x += speed

    if keys[pygame.K_UP] and player2.top > 0:
        player2.y -= speed
    if keys[pygame.K_DOWN] and player2.bottom < HEIGHT:
        player2.y += speed
    if keys[pygame.K_LEFT] and player2.left > 0:
        player2.x -= speed
    if keys[pygame.K_RIGHT] and player2.right < WIDTH:
        player2.x += speed

    # Ball movement
    ball.x += ball_speed[0]
    ball.y += ball_speed[1]

    # Ball collision with walls
    if ball.top <= 0 or ball.bottom >= HEIGHT:
        ball_speed[1] = -ball_speed[1]
    if ball.left <= 0 or ball.right >= WIDTH:
        ball_speed[0] = -ball_speed[0]

    # Ball collision with players
    if ball.colliderect(player1) or ball.colliderect(player2):
        ball_speed[0] = -ball_speed[0]

    # Drawing
    screen.fill(GREEN)
    pygame.draw.rect(screen, WHITE, player1)
    pygame.draw.rect(screen, WHITE, player2)
    pygame.draw.ellipse(screen, BLACK, ball)

    # Update display
    pygame.display.flip()
    clock.tick(60)
