import hashlib
from Crypto import Random
from Crypto.Cipher import AES
from base64 import b64encode, b64decode


class secure_socket:
    def __init__(self):
        self.block_size = AES.block_size
        self.key = hashlib.sha256(str('key').encode()).digest()

    def encrypt(self, plain_text):
        plain_text = self.__pad(plain_text)
        iv = Random.new().read(self.block_size)
        cipher = AES.new(self.key, AES.MODE_CFB, iv)
        encrypted_text = cipher.encrypt(plain_text.encode('utf-8'))
        return b64encode(iv + encrypted_text).decode("utf-8")

    def decrypt(self, encrypted_text):
        encrypted_text = b64decode(encrypted_text)
        iv = encrypted_text[:self.block_size]
        cipher = AES.new(self.key, AES.MODE_CFB, iv)
        plain_text = cipher.decrypt(encrypted_text[self.block_size:]).decode("utf-8")
        return self.__unpad(plain_text)

    def __pad(self, plain_text):
        number_of_bytes_to_pad = self.block_size - len(plain_text) % self.block_size
        ascii_string = chr(number_of_bytes_to_pad)
        padding_str = number_of_bytes_to_pad * ascii_string
        padded_plain_text = plain_text + padding_str
        return padded_plain_text

    @staticmethod
    def __unpad(plain_text):
        last_character = plain_text[len(plain_text) - 1:]
        return plain_text[:-ord(last_character)]


if __name__ == '__main__':
    AESC = secure_socket('shalev')
    enc = AESC.encrypt(r"""
    Eldoria was known for its strong sense of community. The villagers, though diverse in their backgrounds and trades, shared a common bond that united them. Farmers, blacksmiths, bakers, and weavers all worked together to ensure the prosperity of their village. The market square, at the heart of Eldoria, was always bustling with activity. On market days, the square transformed into a vibrant tapestry of colors, sounds, and scents as vendors set up their stalls to sell fresh produce, handmade goods, and exotic spices brought in by traveling merchants.

One of the most beloved figures in Eldoria was Old Man Harrington, the village storyteller. With his snow-white beard, twinkling blue eyes, and a voice that could capture the imagination of young and old alike, Harrington was a living repository of the village’s history and lore. Every evening, villagers would gather around the large oak tree in the center of the square to listen to his tales. He spoke of brave knights who had defended Eldoria from marauding invaders, of wise sages who had unlocked the secrets of the universe, and of enchanted forests where magical creatures still roamed.

Among the many tales Harrington told, one of the most intriguing was the legend of the Lost City of Aurelia. According to the legend, Aurelia was a magnificent city of gold and crystal, hidden deep within the heart of the forest. It was said to be a place of unparalleled beauty and knowledge, where the boundaries between the mortal world and the realm of the gods were blurred. Many had ventured into the forest in search of Aurelia, but none had ever returned, adding to the mystery and allure of the legend.

The legend of Aurelia fascinated a young girl named Elara. With her fiery red hair, curious green eyes, and a spirit of adventure, Elara was known for her insatiable curiosity and determination. She spent hours poring over old maps and ancient texts in the village library, convinced that she could find the Lost City. Despite the warnings of her elders and the dangers that lay ahead, Elara’s determination never wavered.

One crisp autumn morning, Elara set out on her journey. Equipped with a backpack filled with provisions, a map she had meticulously pieced together from various sources, and a heart full of hope, she ventured into the forest. The air was cool and filled with the earthy scent of fallen leaves. Sunlight filtered through the canopy, casting dappled shadows on the forest floor. As she walked deeper into the woods, the sounds of the village faded away, replaced by the rustling of leaves and the occasional call of a distant bird.

Days turned into weeks as Elara navigated the dense forest, facing numerous challenges along the way. She encountered wild animals, treacherous terrain, and harsh weather conditions. But with each obstacle, Elara grew stronger and more determined. She discovered hidden groves, sparkling streams, and ancient ruins that hinted at a forgotten civilization.

One evening, as the sun dipped below the horizon, Elara stumbled upon a clearing bathed in a soft, golden light. In the center of the clearing stood a towering tree, its leaves shimmering with an otherworldly glow. Elara approached the tree, her heart pounding with anticipation. As she reached out to touch its bark, the ground beneath her feet trembled, and the air was filled with a resonant hum. Before her eyes, the tree transformed into a gateway, revealing a path that seemed to lead to another realm.

With a deep breath and a resolve as strong as ever, Elara stepped through the gateway. She found herself in a breathtaking city of gold and crystal, just as the legend had described. The buildings sparkled in the sunlight, and the air was filled with the sweet scent of blooming flowers. Elara’s journey had led her to the Lost City of Aurelia, a place where the wonders of the past and the magic of the present coexisted in perfect harmony.

Elara spent many years in Aurelia, learning its secrets and unlocking the mysteries that had eluded so many before her. She became a bridge between the world of Eldoria and the enchanted realm of Aurelia, sharing her knowledge and experiences with her fellow villagers. Her adventures inspired generations to come, and her name became synonymous with bravery, curiosity, and the unyielding pursuit of knowledge.

As time passed, the legend of Elara and the Lost City of Aurelia became a cherished part of Eldoria’s heritage. The villagers continued to gather around the oak tree in the market square, where new storytellers, inspired by Old Man Harrington and Elara’s adventures, wove tales of wonder and magic. The spirit of exploration and the quest for knowledge lived on in the hearts of the people of Eldoria, ensuring that the village would forever remain a place of mystery, magic, and endless possibilities.
                       
                       """)
    dec = AESC.decrypt(enc)
    print(enc)
    print(dec)
