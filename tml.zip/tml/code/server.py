import os
import socket
import time
from threading import Thread
import sqlite3
from common import *
from dev_txt import chunk_splitter
from recreate_file import file_assembler
from encryption import secure_socket  # Import the SecureSocket class from the encryption module


class server:
    def __init__(self):
        self.server_socket = socket.socket()
        self.port = Globals.port
        self.clients = set()

    def remove_file_entry(self, file_name, paths_cursor, paths_conn):
        try:
            paths_cursor.execute("DELETE FROM paths WHERE name=?", (file_name,))
            paths_conn.commit()
            print(f"File entry '{file_name}' successfully removed from paths.db.")
        except Exception as e:
            print(f"Error removing file entry '{file_name}' from paths.db: {e}")

    def file_exists(self, file_name, paths_cursor):
        # Execute a SELECT query to check if the file name exists in the database
        try:
            paths_cursor.execute('''CREATE TABLE IF NOT EXISTS paths
                                      (name TEXT PRIMARY KEY NOT NULL,
                                      path TEXT NOT NULL)''')
            paths_cursor.execute("SELECT COUNT(*) FROM paths WHERE name=?", (file_name,))
            result = paths_cursor.fetchone()[0]
        except OSError as e:
            print("OG:SERVER - Error inserting data:", e)
        # If the result is greater than 0, it means the file name exists in the database
        return result > 0

    def handle_client(self, client_socket, encryption):
        """Handles a single client connection."""
        while True:
            paths_db_file = os.path.join(os.path.dirname(os.path.abspath(__file__)), f'paths.db')
            paths_conn = sqlite3.connect(paths_db_file)
            paths_cursor = paths_conn.cursor()

            client_info = client_socket.recv(1024)
            print(f"client info!!!!!!!!!  +  {client_info}")
            if client_info != b'':
                decrypted_info = encryption.decrypt(client_info.decode('utf-8'))
            else:
                break
            print(f"info server got is {decrypted_info}")
            info_list = decrypted_info.split(';')

            if info_list[0] == "Enter file":
                data = (';').join(info_list)
                file_name = os.path.basename(info_list[1]) # i give the entire path, not actually necesseray unless we dicdie to implement returning to the same path.
                if self.file_exists(file_name, paths_cursor):
                    data = "Enter file;File already entered"
                    break
                file_info = info_list[2] + ';' + info_list[3]
                self.send_file(file_info, file_name, paths_conn, paths_cursor)


            elif info_list[0] == "Request file":
                print(f"entered req in server op, {info_list[1]}")  # file name
                if self.file_exists(info_list[1], paths_cursor):
                    for row in paths_cursor.execute("SELECT path FROM paths WHERE name=?", (info_list[1],)):
                        path_list = row[0].split(';')
                        for path in path_list:
                            print("f", path)
                        try:
                            assemble = file_assembler(path_list).assemble_files_txt()
                            for path in path_list:
                                try:
                                    os.remove(path)
                                except OSError as e:
                                    print(f"OG: SERVER - file {path} couldn't be removed - {e} ")
                            self.remove_file_entry(info_list[1], paths_cursor, paths_conn)
                        except Exception as e:
                            print(f"couldn't re-assemble: {e}")
                            data = 'Request file response;File not found'
                            break
                        print(assemble)
                        data = str("Request file response" + ';' + info_list[1] + ';' + assemble)  # Request file;xtx.txt;1;he
                        print(data, " is the data I'm sending back as req on server")
                else:
                    data = 'Request file response;File not found'
            else:
                data = ""

            print(f"OG:SERVER - data sent is {data}")
            encrypted_data = encryption.encrypt(data)
            client_socket.send(encrypted_data.encode('utf-8'))
            data = ''
            paths_conn.close()  # Close the connection at the end of each iteration

    def main_server(self):
        while True:
            try:
                self.server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                self.server_socket.bind(("0.0.0.0", self.port))
                print("111", "server bind to port " + str(self.port))
                break
            except socket.error as e:
               print(e)
            time.sleep(1)

        self.my_name = "bb" + str(self.port)
        print(self.my_name, " server start")

        self.server_socket.listen(5)

        while True:
            (client_socket, client_address) = self.server_socket.accept()
            print("7167", "New client connecting")
            self.clients.add(client_socket)
            secure_s = secure_socket()
            a = Thread(target=self.handle_client, args=(client_socket, secure_s))
            a.start()

    def send_file(self, data, file_name, paths_conn, paths_cursor):
        print(f"DATA IS {data}")
        chunks = chunk_splitter()
        path_list = (';').join(chunks.split_into_chunks(data))
        print(path_list)
        try:
            paths_cursor.execute('''CREATE TABLE IF NOT EXISTS paths
                                    (name TEXT PRIMARY KEY NOT NULL,
                                    path TEXT NOT NULL)''')
            paths_cursor.execute("INSERT OR IGNORE INTO paths (name, path) VALUES (?, ?)", (file_name, path_list))
            paths_conn.commit()
            print("Rows inserted:", paths_cursor.rowcount)
        except Exception as e:
            print("Error inserting data:", e)
        finally:
            paths_conn.close()


if __name__ == "__main__":
    print("usage: python main.py")
