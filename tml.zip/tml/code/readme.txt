has ui, login, db, req and send work with 2 clients. also with encrypt.
(?) feature
fixed comm bugs - can send file by NAME, request NAME then again enter NAME file.
i also made it read any file size and not bytes. - communictaion cant recieve messeges of any size :(
peer counter works
14.6 - chill noon