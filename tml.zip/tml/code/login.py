import pygame
import sqlite3
import hashlib
import sys
import os

# Import the file_manager class from common.py
from random_path import file_manager
from main import run

# Initialize Pygame
pygame.init()

# Set up the screen
screen_width = 400
screen_height = 300
screen = pygame.display.set_mode((screen_width, screen_height))
pygame.display.set_caption("Login System")

# Load background image
background_image = pygame.image.load('login_background.png')

# Colors
COLOR1 = (255, 57, 2)   # #ff3902
COLOR2 = (255, 128, 7)  # #ff8007
COLOR3 = (255, 180, 4)  # #ffb404
COLOR4 = (5, 186, 221)  # #05badd
COLOR5 = (43, 72, 113)  # #2b4871
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
GRAY = (200, 200, 200)

# Fonts
font = pygame.font.Font(None, 32)

# Database file path for paths.db
script_dir = os.path.dirname(os.path.abspath(__file__))
paths_db_file = os.path.join(script_dir, 'paths.db')

# Connect to paths.db database
paths_conn = sqlite3.connect(paths_db_file)
paths_cursor = paths_conn.cursor()

# Create table if not exists
paths_cursor.execute('''CREATE TABLE IF NOT EXISTS paths
             (name TEXT PRIMARY KEY NOT NULL,
             path TEXT NOT NULL)''')

# Function to insert path into paths.db
def insert_path(name, path):
    paths_cursor.execute("INSERT INTO paths (name, path) VALUES (?, ?)", (name, path))
    paths_conn.commit()

# Function to check if path exists in paths.db
def path_exists(name):
    paths_cursor.execute("SELECT * FROM paths WHERE name=?", (name,))
    if paths_cursor.fetchone():
        return True
    return False

# Function to check if users table is empty
def is_users_table_empty(cursor):
    cursor.execute("SELECT COUNT(*) FROM users")
    count = cursor.fetchone()[0]
    return count == 0

# Function to display message
def message_to_screen(msg, color, y_displace=0):
    text_surface = font.render(msg, True, color)
    text_rect = text_surface.get_rect(center=(screen_width/2, screen_height/2 + y_displace))
    screen.blit(text_surface, text_rect)

# Function to create button
def create_button(msg, x, y, width, height, inactive_color, active_color, action=None):
    mouse = pygame.mouse.get_pos()
    click = pygame.mouse.get_pressed()

    if x + width > mouse[0] > x and y + height > mouse[1] > y:
        pygame.draw.rect(screen, active_color, (x, y, width, height))
        if click[0] == 1 and action is not None:
            action()
    else:
        pygame.draw.rect(screen, inactive_color, (x, y, width, height))

    text_surface = font.render(msg, True, BLACK)
    text_rect = text_surface.get_rect(center=(x + width / 2, y + height / 2))
    screen.blit(text_surface, text_rect)

# Function to display text input box
def text_input_box(msg, y_displace=0):
    input_box = pygame.Rect(100, 140 + y_displace, 200, 32)
    color_active = COLOR3
    color_inactive = COLOR4
    color = color_inactive
    active = False
    text = ''
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                if input_box.collidepoint(event.pos):
                    active = not active
                else:
                    active = False
                color = color_active if active else color_inactive
            if event.type == pygame.KEYDOWN:
                if active:
                    if event.key == pygame.K_RETURN:
                        return text
                    elif event.key == pygame.K_BACKSPACE:
                        text = text[:-1]
                    else:
                        text += event.unicode
        screen.blit(background_image, (0, 0))
        pygame.draw.rect(screen, color, input_box, 2)
        text_surface = font.render(msg, True, WHITE)
        screen.blit(text_surface, (input_box.x - 80, input_box.y - 30))
        text_surface = font.render(text, True, color)
        screen.blit(text_surface, (input_box.x + 5, input_box.y + 5))
        pygame.display.flip()

# Function to check login
def check_login(username, password, cursor):
    hashed_input_password = hashlib.md5(password.encode()).hexdigest()
    cursor.execute("SELECT * FROM users WHERE username=?", (username,))
    user_data = cursor.fetchone()
    if user_data:
        hashed_db_password = user_data[1]
        if hashed_input_password == hashed_db_password:
            return True
    return False

# Function to create new user
def create_user(username, password, cursor, conn):
    hashed_password = hashlib.md5(password.encode()).hexdigest()
    try:
        cursor.execute("INSERT INTO users (username, password) VALUES (?, ?)", (username, hashed_password))
        conn.commit()
    except sqlite3.IntegrityError:
        # Username already exists
        return False
    return True

# Main function
def main():
    # Database file path for users.db
    db_name = '.localappdata.db'

    # Check if path exists in paths.db
    if path_exists(db_name):
        paths_cursor.execute("SELECT path FROM paths WHERE name=?", (db_name,))
        db_path = paths_cursor.fetchone()[0] # db_name is the secretive name of the login data base. path to it is stored on the first line of paths_data_base
    else:
        # Generate a random path
        fm = file_manager()
        db_path = fm.generate_random_path()
        insert_path(db_name, db_path)

    # Connect to users.db database
    db_conn = sqlite3.connect(db_path)
    db_cursor = db_conn.cursor()

    # Create table if not exists
    db_cursor.execute('''CREATE TABLE IF NOT EXISTS users
                 (username TEXT PRIMARY KEY NOT NULL,
                 password TEXT NOT NULL)''')

    while True:
        screen.blit(background_image, (0, 0))
        if is_users_table_empty(db_cursor):
            create_button("Sign Up", 100, 120, 200, 50, COLOR1, COLOR2, lambda: sign_up(db_cursor, db_conn))
        else:
            create_button("Login", 100, 120, 200, 50, COLOR1, COLOR2, lambda: login(db_cursor))
        pygame.display.update()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

# Function for login
def login(cursor):
    screen.blit(background_image, (0, 0))
    message_to_screen("Login", WHITE, -50)
    message_to_screen("Username:", WHITE, -20)
    username = text_input_box("Enter username:", 0)
    message_to_screen("Password:", WHITE, 20)
    password = text_input_box("Enter password:", 40)

    if check_login(username, password, cursor):
        message_to_screen("Login successful!", WHITE, 80)
        call_main = run()
        call_main.main()
    else:
        message_to_screen("Login failed. Please try again.", COLOR1, 80)
    pygame.display.update()
    pygame.time.wait(2000)  # Pause for 2 seconds before returning to main menu

# Function for sign up
def sign_up(cursor, conn):
    screen.blit(background_image, (0, 0))
    message_to_screen("Sign Up", WHITE, -50)
    message_to_screen("Username:", WHITE, -20)
    username = text_input_box("Enter username:", 0)
    message_to_screen("Password:", WHITE, 20)
    password = text_input_box("Enter password:", 40)

    if create_user(username, password, cursor, conn):
        message_to_screen("User created successfully!", WHITE, 80)
    else:
        message_to_screen("Username already exists. Please choose a different username.", COLOR1, 80)
    pygame.display.update()
    pygame.time.wait(2000)  # Pause for 2 seconds before returning to main menu

if __name__ == "__main__":
    main()
